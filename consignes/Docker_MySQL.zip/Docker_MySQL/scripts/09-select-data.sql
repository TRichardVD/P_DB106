-- Afficher toutes les données de la table t_book
-- (remplacer ce commentaire par la commande SQL adéquate)

