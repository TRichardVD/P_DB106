
-- Insérer dans la table t_book de la base de données db_book les données suivantes :
-- booTitre = Don Quixote , booAuteur = Miguel de Cervantes
-- booTitre = The great Gatsby , booAuteur = F. Scott Fitzgerald

-- (remplacer ce commentaire par la commande SQL adéquate)

